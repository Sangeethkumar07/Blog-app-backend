package com.example.Blog.playloads;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentDto {

	private Long commentId;

	private String content;
	
}
